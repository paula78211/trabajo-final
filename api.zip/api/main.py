from datetime import datetime
from fastapi import FastAPI
from flask import request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import mysql.connector
from pymongo import MongoClient
from bson import ObjectId


# Crear instancia de FastAPI
app = FastAPI()

# Conexión a MySQL
mysql_conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="12345",
    database="cuteculture",
    auth_plugin='mysql_native_password'
)

# Conexión a MongoDB (URI proporcionada)
mongo_client = MongoClient("mongodb+srv://root:12345@clustergratis.xldjn.mongodb.net/")
mongo_db = mongo_client["mibase_mongo"]  # Selección de base de datos
comments_collection = mongo_db["Comentarios"]

# Pydantic models para validar la entrada
class CompraRequest(BaseModel):
    idCliente: int
    idProducto: int
    cantidad: int
    direccion: str
    telefono: str
    descripcionCasa: str

class DevolucionRequest(BaseModel):
    idCompra: int
    motivo: str
    descripcionMotivo: str

class ComentarioRequest(BaseModel):
    idProducto: int
    idCliente: int
    comentario: str
    calificacion: int

# Pydantic model para editar comentarios
class EditarComentarioRequest(BaseModel):
    idComentario: str
    comentario: str
    calificacion: int


# Configuración de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permitir solicitudes desde cualquier origen
    allow_credentials=True,
    allow_methods=["*"],  # Permitir todos los métodos HTTP
    allow_headers=["*"]   # Permitir todos los encabezados
)


# Rutas
@app.get("/")
def root():
    return {"mensaje": "Hello World"}

# Endpoint para verificar la conexión a MySQL
@app.get("/mysql/status")
def mysql_status():
    if mysql_conn.is_connected():
        return {"status": "Conexión a MySQL exitosa"}
    return JSONResponse(status_code=500, content={"status": "Error en la conexión a MySQL"})

# Endpoint para verificar la conexión a MongoDB
@app.get("/mongo/status")
def mongo_status():
    response = mongo_client.admin.command('ping')
    if response.get("ok") == 1.0:
        return {"status": "Conexión a MongoDB exitosa"}
    
    return JSONResponse(status_code=500, content={"status": "Error en la conexión a MongoDB"})


# Ruta para realizar una compra
@app.post("/compra")
async def realizar_compra(compra_data: CompraRequest):
    # Validar que los datos sean correctos
    if not compra_data.idCliente or not compra_data.idProducto or not compra_data.cantidad:
        return JSONResponse(status_code=400, content={"message": "Faltan datos requeridos"})

    try:
        # Realizar la compra a través del procedimiento almacenado
        cursor = mysql_conn.cursor()
        cursor.callproc("RegistrarCompra", (
            compra_data.idCliente,
            compra_data.idProducto,
            compra_data.cantidad,
            compra_data.direccion,
            compra_data.telefono,
            compra_data.descripcionCasa
        ))
        mysql_conn.commit()
        cursor.close()
        return {"message": "Compra registrada exitosamente."}
    except mysql.connector.Error as e:
        return JSONResponse(status_code=500, content={"message": f"Error al realizar la compra: {e}"})


# Ruta para registrar una devolución
@app.post("/devolucion")
async def registrar_devolucion(devolucion_data: DevolucionRequest):
    # Validar que los datos sean correctos
    if not devolucion_data.idCompra or not devolucion_data.motivo or not devolucion_data.descripcionMotivo:
        return JSONResponse(status_code=400, content={"message": "Faltan datos requeridos"})

    # Registrar la devolución a través del procedimiento almacenado
    cursor = mysql_conn.cursor()
    cursor.callproc("RegistrarDevolucion", (devolucion_data.idCompra, devolucion_data.motivo, devolucion_data.descripcionMotivo))
    mysql_conn.commit()
    cursor.close()
    return {"message": "Devolución registrada exitosamente."}

# Ruta para generar el reporte de devolución
@app.get("/reporte_devolucion/{id_compra}")
async def generar_reporte_devolucion(id_compra: int):
    if not id_compra:
        return JSONResponse(status_code=400, content={"message": "ID de compra inválido"})
    
    try:
        # Ejecutar el procedimiento almacenado para generar el reporte
        cursor = mysql_conn.cursor()
        cursor.callproc("GenerarReporteDevolucion", (id_compra,))
        result_sets = cursor.stored_results()
        report_data = []
        for result in result_sets:
            column_names = [desc[0] for desc in result.description]
            rows = result.fetchall()
            for row in rows:
                row_data = {column_names[i]: row[i] for i in range(len(column_names))}
                report_data.append(row_data)
        cursor.close()       
        if report_data:
            return {"reporte": report_data}
        else:
            return JSONResponse(status_code=404, content={"message": "No se encontró información para el reporte."})  
    except mysql.connector.Error as e:
        return JSONResponse(status_code=500, content={"message": f"Error al generar el reporte: {e}"})






@app.get("/sucursal_cercana/{idCliente}")
async def sucursal_cercana(idCliente: int):
    # Validar que el cliente exista y que idCliente sea un valor válido
    if not idCliente or idCliente <= 0:
        return JSONResponse(status_code=400, content={"message": "ID de cliente inválido"})

    # Realizar la consulta espacial para obtener la sucursal más cercana
    cursor = mysql_conn.cursor()
    query = """
        SELECT idSucursal, nombre, ST_Distance(coordenadas, (SELECT ubicacion FROM Clientes WHERE idCliente = %s)) AS distancia
        FROM Sucursales
        ORDER BY distancia ASC
        LIMIT 1;
    """
    cursor.execute(query, (idCliente,))
    result = cursor.fetchone()
    cursor.close()

    if result:
        return {"idSucursal": result[0], "nombre": result[1], "distancia": result[2]}
    return JSONResponse(status_code=404, content={"message": "No se encontraron sucursales cercanas."})




# Ruta para dejar un comentario o calificación en un producto
@app.post("/comentario")
async def registrar_comentario(comentario_data: ComentarioRequest):
    # Validar que los datos sean correctos
    if not comentario_data.idProducto or not comentario_data.idCliente or not comentario_data.comentario or not comentario_data.calificacion:
        return JSONResponse(status_code=400, content={"message": "Faltan datos requeridos"})

    # Insertar el comentario en MongoDB
    comment_data = {
        'idProducto': comentario_data.idProducto,
        'idCliente': comentario_data.idCliente,
        'comentario': comentario_data.comentario,
        'calificacion': comentario_data.calificacion,
        'fecha': datetime.now()
    }
    comments_collection.insert_one(comment_data)
    return {"message": "Comentario registrado exitosamente."}


# Ruta para obtener los comentarios y el nombre del cliente
@app.get("/comentarios/{producto_id}")
async def obtener_comentarios(producto_id: int):
    if not producto_id:
        return JSONResponse(status_code=400, content={"message": "ID de producto inválido"})

    # Consulta a MongoDB para obtener los comentarios del producto
    comentarios = comments_collection.find({'idProducto': producto_id})
    
    comentarios_list = []
    for comentario in comentarios:
        id_cliente = comentario['idCliente']

        # Consulta a MySQL para obtener el nombre del cliente
        cursor = mysql_conn.cursor(dictionary=True)
        cursor.execute("SELECT nombre FROM Clientes WHERE idCliente = %s", (id_cliente,))
        cliente = cursor.fetchone()
        
        if cliente:
            cliente_nombre = cliente['nombre']
        else:
            cliente_nombre = "Cliente no encontrado"
        
        # Agregar el comentario y el nombre del cliente a la respuesta
        comentarios_list.append({
            'idCliente': id_cliente,
            'nombreCliente': cliente_nombre,
            'comentario': comentario['comentario'],
            'calificacion': comentario['calificacion'],
            'fecha': comentario['fecha']
        })

    return comentarios_list


@app.put("/comentario/{comentario_id}")
async def editar_comentario(comentario_id: str, comentario_data: ComentarioRequest):
    # Validar que los datos sean correctos
    if not comentario_data.comentario or not comentario_data.calificacion:
        return JSONResponse(status_code=400, content={"message": "Faltan datos requeridos"})
    # Verificar si el comentario_id es un ObjectId válido
    if not ObjectId.is_valid(comentario_id):
        return JSONResponse(status_code=400, content={"message": "ID de comentario inválido"})
    # Convertir el comentario_id a ObjectId
    comentario_object_id = ObjectId(comentario_id)
    # Buscar el comentario por su ObjectId
    comentario = comments_collection.find_one({"_id": comentario_object_id})   
    # Verificar si el comentario existe
    if not comentario:
        return JSONResponse(status_code=404, content={"message": "Comentario no encontrado"})
    # Verificar si el cliente que realiza la edición es el mismo que creó el comentario
    if comentario['idCliente'] != comentario_data.idCliente:
        return JSONResponse(status_code=403, content={"message": "No tienes permiso para editar este comentario"})
    # Datos a actualizar
    updated_data = {
        'comentario': comentario_data.comentario,
        'calificacion': comentario_data.calificacion,
        'fecha': datetime.now()  # Actualizar la fecha con la hora actual
    }
    # Realizar la actualización
    result = comments_collection.update_one(
        {"_id": comentario_object_id},  # Filtrar por el _id del comentario
        {"$set": updated_data}          # Establecer los nuevos valores
    )
    # Verificar si la actualización fue exitosa
    if result.matched_count == 0:
        return JSONResponse(status_code=404, content={"message": "Comentario no encontrado"})
    return {"message": "Comentario actualizado exitosamente."}



# Ruta para obtener todas las compras de un cliente
@app.get("/compras/{id_cliente}")
async def obtener_compras(id_cliente: int):
    if not id_cliente:
        return JSONResponse(status_code=400, content={"message": "ID de cliente inválido"})

    cursor = mysql_conn.cursor()
    cursor.execute("SELECT * FROM Compras WHERE idCliente = %s", (id_cliente,))
    compras = cursor.fetchall()
    cursor.close()
    compras_list = []
    for compra in compras:
        compras_list.append({
            'idCompra': compra[0],
            'idCliente': compra[1],
            'idProducto': compra[2],
            'cantidad': compra[3],
            'fecha': compra[4],
            'valorTotal': compra[8]
        })
    return compras_list


# Ruta para obtener todas las devoluciones de un cliente
@app.get("/devoluciones/{id_cliente}")
async def obtener_devoluciones(id_cliente: int):
    if not id_cliente:
        return JSONResponse(status_code=400, content={"message": "ID de cliente inválido"})

    cursor = mysql_conn.cursor()
    cursor.execute("""
        SELECT D.idDevolucion, D.motivo, D.descripcionMotivo, D.fecha 
        FROM Devoluciones D 
        JOIN Compras C ON D.idCompra = C.idCompra 
        WHERE C.idCliente = %s
    """, (id_cliente,))
    devoluciones = cursor.fetchall()
    cursor.close()
    devoluciones_list = []
    for devolucion in devoluciones:
        devoluciones_list.append({
            'idDevolucion': devolucion[0],
            'motivo': devolucion[1],
            'descripcionMotivo': devolucion[2],
            'fecha': devolucion[3]
        })
    return devoluciones_list


# Ruta para obtener los productos de la base de datos
@app.get("/productos")
def obtener_productos():
    cursor = mysql_conn.cursor()
    cursor.execute("SELECT * FROM Productos")
    productos = cursor.fetchall()
    cursor.close()
    
    productos_list = []
    for producto in productos:
        productos_list.append({
            'idProducto': producto[0],
            'nombre': producto[1],
            'descripcion': producto[2],
            'precio': producto[3],
            'stock': producto[4],
            'stockMinimo': producto[5]
        })
    
    return productos_list

@app.get("/buscar_productos")
def buscar_productos():
    # Obtener el parámetro 'query' desde la URL
    query = request.args.get('query', '')

    # Si no hay término de búsqueda, devolver todos los productos
    if not query:
        return obtener_productos()  # Llama a la función que ya tienes para obtener todos los productos

    cursor = mysql_conn.cursor()
    # Busca por nombre o descripción (ajusta la consulta según tus necesidades)
    cursor.execute("SELECT * FROM Productos WHERE nombre LIKE %s OR descripcion LIKE %s", ('%' + query + '%', '%' + query + '%'))
    productos = cursor.fetchall()
    cursor.close()

    productos_list = []
    for producto in productos:
        productos_list.append({
            'idProducto': producto[0],
            'nombre': producto[1],
            'descripcion': producto[2],
            'precio': producto[3],
            'stock': producto[4],
            'stockMinimo': producto[5]
        })

    return productos_list


# Ruta para obtener todos los comentarios de la base de datos
@app.get("/comentarios")
async def obtener_comentarios_todos():
    # Consultar todos los comentarios desde MongoDB
    comentarios = comments_collection.find()
    comentarios_list = []
    for comentario in comentarios:
        comentarios_list.append({
            'idProducto': comentario['idProducto'],
            'idCliente': comentario['idCliente'],
            'comentario': comentario['comentario'],
            'calificacion': comentario['calificacion'],
            'fecha': comentario['fecha']
        })
    return comentarios_list


# Ruta para obtener todas las devoluciones de la base de datos
@app.get("/devoluciones")
async def obtener_devoluciones_todos():
    cursor = mysql_conn.cursor()
    cursor.execute("SELECT * FROM Devoluciones")
    devoluciones = cursor.fetchall()
    cursor.close()
    
    devoluciones_list = []
    for devolucion in devoluciones:
        devoluciones_list.append({
            'idDevolucion': devolucion[0],
            'idCompra': devolucion[1],
            'motivo': devolucion[2],
            'descripcionMotivo': devolucion[3],
            'fecha': devolucion[4]
        })
    return devoluciones_list


# Ruta para obtener todas las compras de la base de datos
@app.get("/compras")
async def obtener_compras_todos():
    cursor = mysql_conn.cursor()
    cursor.execute("SELECT * FROM Compras")
    compras = cursor.fetchall()
    cursor.close()
    
    compras_list = []
    for compra in compras:
        compras_list.append({
            'idCompra': compra[0],
            'idCliente': compra[1],
            'idProducto': compra[2],
            'cantidad': compra[3],
            'fecha': compra[4],
            'valorTotal': compra[8]
        })
    return compras_list

